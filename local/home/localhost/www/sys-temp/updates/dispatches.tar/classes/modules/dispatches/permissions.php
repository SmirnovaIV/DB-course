<?php
	$permissions = Array(
		'dispatches_list' => Array(
			'add',
			'edit',
			'activity',
			'del',
			'messages',
			'subscribers',
			'releasees',
			'fill_release',
			'release_send',
			'lists',
			'add_message',
			'releases'
		),

		'subscribe' => Array(
			'subscribe_do',
			'unsubscribe'
		)
	);
?>
