<?php
	abstract class __custom_dispatches {
		//TODO: Write here your own macroses
	};
?>