<?php
	abstract class __dispatches_dispatches extends baseModuleAdmin {

	};
?>