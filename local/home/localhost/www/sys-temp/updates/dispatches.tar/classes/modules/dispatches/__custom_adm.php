<?php
	abstract class __dispatches_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>