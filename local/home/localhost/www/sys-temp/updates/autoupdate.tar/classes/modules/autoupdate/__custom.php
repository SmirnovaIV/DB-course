<?php
	abstract class __autoupdate_custom {
		//TODO: Write here your own macroses
	};
?>
