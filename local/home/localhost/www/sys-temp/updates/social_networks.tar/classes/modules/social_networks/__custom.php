<?php
	abstract class __social_networks_custom {
		//TODO: Write here your own macroses
	};
?>
