<?php
	class facebook_social_network extends social_network {

		
	};
?>