<?php

$INFO = Array();

$INFO['version'] = "2.0.0.0";
$INFO['version_line'] = "lite";

$INFO['name'] = "social_networks";
$INFO['title'] = "Интеграция с социальными сетями";
$INFO['filename'] = "modules/social_networks/class.php";
$INFO['config'] = "0";
$INFO['ico'] = "ico_social_networks";
$INFO['default_method'] = "vkontakte";
$INFO['default_method_admin'] = "vkontakte";
$INFO['is_indexed'] = "0";
$INFO['per_page'] = 10;


$INFO['func_perms'] = "";


$SQL_INSTALL = Array();

$COMPONENTS = array();


?>