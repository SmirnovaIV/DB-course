<?php
	abstract class __social_networks_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>