<?php
$C_LANG = Array();
$C_LANG['module_name'] = "Интеграция с социальными сетями";

$C_LANG['module_title'] = 'Интеграция с социальными сетями';
$C_LANG['module_description'] = 'Модуль интеграции с социальными сетями позволяет ';

$C_LANG['config'] = 'Настройки модуля';


$LANG_EXPORT = Array();
?>