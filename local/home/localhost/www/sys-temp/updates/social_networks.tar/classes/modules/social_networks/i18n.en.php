<?php

$i18n = Array(

	"header-social_networks-vkontakte"  => "Vkontakte",
	'header-social_networks-facebook' 	=> 'Facebook',
	
	'header-social_networks-settings' 	=> 'Setting integration with',


    'label-config-pages'    			=> 'Choose pages for displaying Vkontakte',

);

?>