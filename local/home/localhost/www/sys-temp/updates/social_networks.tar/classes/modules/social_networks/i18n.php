<?php

$i18n = Array(

	"header-social_networks-vkontakte"	=>	"Вконтакте",
	'header-social_networks-facebook'	=>	'Facebook',
	
	'header-social_networks-settings'	=>	'Настройка интеграции с ',
	'label-config-pages'				=>	'Выберите страницы для отображения Вконтакте',
	'social_network-system'				=>	'Служебные свойства',
	
	'perms-social_networks-view'		=>	'Просмотр'

);

?>