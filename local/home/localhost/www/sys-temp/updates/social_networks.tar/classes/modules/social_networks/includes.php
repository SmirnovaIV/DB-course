<?php
	
	$includePath = CURRENT_WORKING_DIR . '/classes/modules/social_networks/classes';
	require $includePath . '/network.php';
	
?>