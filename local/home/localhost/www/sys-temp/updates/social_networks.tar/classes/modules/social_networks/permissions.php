<?php
	$permissions = Array(
		"view" => Array(
			'vkontakte', "includeApi", "getCurrentSocialParams"
		),

	);
?>