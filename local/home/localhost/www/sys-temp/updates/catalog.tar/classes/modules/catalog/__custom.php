<?php
	abstract class __custom_catalog {
		//TODO: Write here your own macroses
	};
?>