<?php

$i18n = Array(
	"label-add-list"		=> "Add category",
	"label-add-item"		=> "Add object",

	"header-catalog-tree"		=> "Goods and categories",
	"header-catalog-config"		=> "Module settings",
	"header-catalog-edit"		=> "Edit",
	"header-catalog-add"		=> "Create",
	"header-catalog-activity"	=> "Activity switch",

	"header-catalog-add-category"	=> "Add category",
	"header-catalog-add-object"		=> "Add object",
	"header-catalog-edit-category"	=> "Edit category",
	"header-catalog-edit-object"	=> "Edit object",

	'perms-catalog-tree' => 'Change',
	'perms-catalog-view' => 'View',
	'perms-catalog-publish' => 'Publish',
	'perms-catalog-addCatalogObject' => 'Add item from site',

	'error-expect-category' => 'Category does not exsit'
);

?>