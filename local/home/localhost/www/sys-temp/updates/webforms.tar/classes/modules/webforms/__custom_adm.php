<?php
	abstract class __webforms_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>