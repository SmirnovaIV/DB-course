<?php
	abstract class __custom_webforms {
		//TODO: Write here your own macroses
	};
?>