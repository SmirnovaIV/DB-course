<?php
	abstract class __custom_events {
		//TODO: Write here your own macroses
	}
?>