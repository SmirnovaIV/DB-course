<?php
	$permissions = Array(
		'projects' => Array('project', 'category', 'question'), 
		'post_question' => Array('addquestionform'), 
		'projects_list' => Array('project_add_do', 'project_edit', 'project_edit_do', 'project_blocking', 'project_del', 'categories_list', 'category_add', 'category_add_do', 'category_edit', 'category_edit_do', 'category_blocking', 'category_del', 'questions_list', 'question_add', 'question_add_do', 'question_edit', 'question_edit_do', 'question_blocking', 'question_del', 'category.edit', 'project.edit', 'question.edit', 'add', 'edit', 'del', 'activity', 'publish')
	);
?>