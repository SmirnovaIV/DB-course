<?php
	abstract class __faq_custom {
		//TODO: Write here your own macroses
	};

?>