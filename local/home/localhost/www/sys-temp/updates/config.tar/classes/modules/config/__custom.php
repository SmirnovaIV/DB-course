<?php
	abstract class __config_custom {
		//TODO: Write here your own macroses
	};
?>
