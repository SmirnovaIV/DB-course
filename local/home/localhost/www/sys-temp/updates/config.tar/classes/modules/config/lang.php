<?php

$C_LANG = Array();

$C_LANG['module_name'] = "Конфигурация";

$C_LANG['module_title'] = "Настройка системы";
$C_LANG['module_description'] = <<<END

Конфигурационный модуль позволяет установить или удалить модуль.<br />
Обеспечивает управление языками и доменами.

END;

$C_LANG['mainpage'] = "Главная страница";
$C_LANG['header'] = "Заголовок страницы";
$C_LANG['title'] = "Просто title ;)";
$C_LANG['test'] = "Настройка системы";
$C_LANG['modules'] = "Управление модулями";
$C_LANG['add_module'] = "Установка модуля";
$C_LANG['main'] = "Основные настройки сайта";
$C_LANG['langs'] = "Языки";
$C_LANG['URL'] = "Псевдостатические адреса";
$C_LANG['del_module'] = "Удаление модуля";
$C_LANG['domains'] = "Настройка доменов";
$C_LANG['memcached'] = "Настройки подключения к memcached";
$C_LANG['mails'] = "Настройки исходящих писем";
$C_LANG['domain_mirrows'] = "Зеркала домена";

$LANG_EXPORT = Array();

?>