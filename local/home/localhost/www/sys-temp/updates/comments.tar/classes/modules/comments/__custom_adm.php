<?php
	abstract class __comments_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>