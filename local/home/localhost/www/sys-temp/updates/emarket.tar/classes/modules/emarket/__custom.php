<?php
	abstract class __emarket_custom {
		//TODO: Write here your own macroses
	};
?>
