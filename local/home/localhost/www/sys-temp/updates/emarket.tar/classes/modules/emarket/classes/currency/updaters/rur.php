<?php

	class rurCurrencyUpdater extends currencyUpdater {
		/*
		public function getRate() {
			//TODO: Implement
		}
		*/
	};
?>