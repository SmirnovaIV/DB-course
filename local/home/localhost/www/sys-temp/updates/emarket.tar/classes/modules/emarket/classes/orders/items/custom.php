<?php
/**
	* Пользовательский класс для товаров в заказе
*/
	class customOrderItem extends optionedOrderItem {
		//TODO: Whatever you want...
	};
?>