<?php
	class usdCurrencyUpdater extends currencyUpdater {
		protected function getRate() {
			return parent::getRate();
		}
	};
?>