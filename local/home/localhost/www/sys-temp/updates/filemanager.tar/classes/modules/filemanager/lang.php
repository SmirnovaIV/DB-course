<?php
$C_LANG = Array();

$C_LANG['module_name'] = "Файловая система";
$C_LANG['module_title'] = "Файловая система";
$C_LANG['module_description'] = <<<DESC
	Управление файловой системой.
DESC;

$C_LANG['config'] = "Настройки модуля";

$C_LANG['directory_list'] = "Файловая система";
$C_LANG['shared_files'] = "Скачиваемые файлы";
$C_LANG['add_shared_file'] = "Добавление скачиваемого файла";
$C_LANG['edit_shared_file'] = "Редактирование скачиваемого файла";

$LANG_EXPORT = Array();

$LANG_EXPORT['fs_cifi_upload_text'] = 'Закачать';

?>