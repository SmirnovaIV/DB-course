<?php
	$permissions = Array(
		'list_files' => Array('shared_file'), 
		'download' => Array(), 
		'directory_list' => Array('rename', 'del', 'shared_file.edit', 'add_shared_file', 'add_shared_file_do', 'remove', 'edit_shared_file', 'edit_shared_file_do', 'shared_file_blocking', 'publish', 'make_directory', 'shared_files', 'del_shared_file')
	);
?>