<?php
	abstract class __filemanager_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>