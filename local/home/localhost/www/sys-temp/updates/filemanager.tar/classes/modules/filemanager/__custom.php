<?php
	abstract class __custom_filemanager {
		//TODO: Write here your own macroses
	};
?>