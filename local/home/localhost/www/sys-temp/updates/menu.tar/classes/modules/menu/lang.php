<?php
$C_LANG = Array();
 
$C_LANG['module_name'] = "menu";
 
$LANG_EXPORT = Array();
?>