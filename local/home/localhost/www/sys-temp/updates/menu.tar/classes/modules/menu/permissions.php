<?php
$permissions = Array(
	'view' => Array('draw'),
	'lists' => Array('lists', 'add', 'edit', 'del', 'item_element.edit', 'activity', 'publish')
);
?>