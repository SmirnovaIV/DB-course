<?php
	abstract class __custom_search {
		//TODO: Write your macroses here
	};
?>