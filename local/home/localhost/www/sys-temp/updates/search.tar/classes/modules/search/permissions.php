<?php
	$permissions = Array(
		'index' => Array('index_all', 'index_item', 'elementisreindexed', 'index_control', 'reindex', 'truncate', 'partialReindex'), 
		'search' => Array('runsearch', 'search_do', 'insert_form', 'suggestions')
	);
?>