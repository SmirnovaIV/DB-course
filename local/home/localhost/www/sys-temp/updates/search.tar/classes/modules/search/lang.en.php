<?php
$C_LANG = Array();

$C_LANG['module_name'] = "Search";

$C_LANG['module_title'] = "Site search";

$C_LANG['search_do'] = "Search";
$C_LANG['config'] = "Settings";

$C_LANG['index_all'] = "Index changed pages";
$C_LANG['index_all_mode'] = "Index all pages";

$C_LANG['index_control'] = "Search";

$LANG_EXPORT = Array();
$LANG_EXPORT['search_sform'] = "Search form";
$LANG_EXPORT['search_index_new'] = "Index new";
$LANG_EXPORT['search_index_all'] = "Index all";
$LANG_EXPORT['search_matches'] = "matches";
$LANG_EXPORT['search_nothingfounded'] = "Requested page not found.";
$LANG_EXPORT['search_maybewant'] = "May be, you wanted to find ";
$LANG_EXPORT['search_stext'] = "Search: ";
$LANG_EXPORT['search_dosearch'] = "Search!";
$LANG_EXPORT['search_founded_total'] = " pages";
$LANG_EXPORT['search_founded_total1'] = "Found";
$LANG_EXPORT['search_founded_total2'] = " by your request.";
$LANG_EXPORT['search_redirect_text'] = "Redirect on page ";

$LANG_EXPORT['search_input_text'] = "Search";
?>