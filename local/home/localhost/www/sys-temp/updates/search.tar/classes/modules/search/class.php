<?php
	class search extends def_module {

		public function __construct() {
			parent::__construct();
			$configTabs = $this->getConfigTabs();

			if(cmsController::getInstance()->getCurrentMode() == "admin") {
				$commonTabs = $this->getCommonTabs();

				$this->__loadLib("__admin.php");
				$this->__implement("__search");

				if ($commonTabs) {
					$commonTabs->add('sphinx_control');
				}

				if($configTabs) {
					$configTabs->add("config");
				}

				$this->__loadLib("sphinx/SphinxIndexGenerator.php");

				$this->__loadLib("__custom_adm.php");
				$this->__implement("__search_custom_admin");
			} else {
				$this->per_page = regedit::getInstance()->getVal("//modules/search/per_page");
			}

			$this->__loadLib("sphinx/sphinxapi.php");

			$this->__loadLib("__custom.php");
			$this->__implement("__custom_search");
		}

		public function search_do($template = "default", $search_string = "", $search_types = "", $search_branches = "", $per_page = 0) {
			// поисковая фраза :
			if (!$search_string) {
				$search_string = (string) getRequest('search_string');
			}

			$p = (int) getRequest('p');
			// если запрошена нетипичная постраничка
			if (!$per_page) {
				$per_page = intval(getRequest('per_page'));
			}
			if (!$per_page) {
				$per_page = $this->per_page;
			}

			$config = mainConfiguration::getInstance();
			$searchEngine = $config->get('modules', 'search.using-sphinx');
			if ($searchEngine){
				return $this->sphinxSearch($template, $search_string, $per_page, $p);
			}

			list(
				$template_block, $template_line, $template_empty_result, $template_line_quant
			) = self::loadTemplates("search/".$template,
				"search_block", "search_block_line", "search_empty_result", "search_block_line_quant"
			);

			$block_arr = Array();
			$block_arr['last_search_string'] = $search_string;

			$search_string = urldecode($search_string);
			$search_string = htmlspecialchars($search_string);
			$search_string = str_replace(". ", " ", $search_string);
			$search_string = trim($search_string, " \t\r\n%");
			$search_string = str_replace(array('"', "'"), "", $search_string);

			$orMode = (bool) getRequest('search-or-mode');

			if (!$search_string) return $this->insert_form($template);

			// если запрошен поиск только по определенным веткам :
			$arr_search_by_rels = array();
			if (!$search_branches) $search_branches = (string) getRequest('search_branches');
			$search_branches = trim(rawurldecode($search_branches));
			if (strlen($search_branches)) {
				$arr_branches = preg_split("/[\s,]+/", $search_branches);
				foreach ($arr_branches as $i_branch => $v_branch) {
					$arr_branches[$i_branch] = $this->analyzeRequiredPath($v_branch);
				}
				$arr_branches = array_map('intval', $arr_branches);
				$arr_search_by_rels = array_merge($arr_search_by_rels, $arr_branches);
				$o_selection = new umiSelection;
				$o_selection->addHierarchyFilter($arr_branches, 100, true);
				$o_result = umiSelectionsParser::runSelection($o_selection);
				$sz = sizeof($o_result);
				for ($i = 0; $i < $sz; $i++) $arr_search_by_rels[] = intval($o_result[$i]);
			}
			// если запрошен поиск только по определенным типам :
			if (!$search_types) $search_types = (string) getRequest('search_types');
			$search_types = rawurldecode($search_types);
			if (strlen($search_types)) {
				$search_types = preg_split("/[\s,]+/", $search_types);
				$search_types = array_map('intval', $search_types);
			}

			$lines = Array();
			$result = searchModel::getInstance()->runSearch($search_string, $search_types, $arr_search_by_rels, $orMode);
			$total = sizeof($result);

			$result = array_slice($result, $per_page * $p, $per_page);

			$i = $per_page * $p;

			foreach($result as $num => $element_id) {
				$line_arr = Array();

				$element = umiHierarchy::getInstance()->getElement($element_id);

				if(!$element) continue;

				$line_arr['void:num'] = ++$i;
				$line_arr['attribute:id'] = $element_id;
				$line_arr['attribute:name'] = $element->getName();
				$line_arr['attribute:link'] = umiHierarchy::getInstance()->getPathById($element_id);
				$line_arr['xlink:href'] = "upage://" . $element_id;
				$line_arr['node:context'] = searchModel::getInstance()->getContext($element_id, $search_string);
				$line_arr['void:quant'] = ($num < count($result)-1? self::parseTemplate($template_line_quant, array()) : "");
				$lines[] = self::parseTemplate($template_line, $line_arr, $element_id);

				$this->pushEditable(false, false, $element_id);

				umiHierarchy::getInstance()->unloadElement($element_id);
			}

			$block_arr['subnodes:items'] = $block_arr['void:lines'] = $lines;
			$block_arr['total'] = $total;
			$block_arr['per_page'] = $per_page;

			return self::parseTemplate(($total > 0 ? $template_block : $template_empty_result), $block_arr);
		}


		public function insert_form($template = "default") {
			if(defined("DB_DRIVER") && DB_DRIVER == "xml") return;
			list($template_block) = self::loadTemplates("search/".$template, "search_form");

			$search_string = (string) getRequest('search_string');
			$search_string = strip_tags($search_string);
			$search_string = trim($search_string, " \t\r\n%");
			$search_string = htmlspecialchars(urldecode($search_string));
			$search_string = str_replace(array('"', "'"), "", $search_string);

			$orMode = (bool) getRequest('search-or-mode');

			$block_arr = Array();
			$block_arr['last_search_string'] = ($search_string) ? $search_string : "%search_input_text%";

			if($orMode) {
				$block_arr['void:search_mode_and_checked'] = "";
				$block_arr['void:search_mode_or_checked'] = " checked";
			} else {
				$block_arr['void:search_mode_and_checked'] = " checked";
				$block_arr['void:search_mode_or_checked'] = "";
			}
			return self::parseTemplate($template_block, $block_arr);
		}

		public function suggestions($template = 'default', $string = false, $limit = 10) {
			if($string == false) $string = getRequest('suggest-string');

			list($template_block, $template_line, $template_block_empty) = self::loadTemplates(
				"tpls/search/".$template, "suggestion_block", "suggestion_block_line", "suggestion_block_empty"
			);

			$search = searchModel::getInstance();
			$words = $search->suggestions($string, $limit);
			$total = sizeof($words);

			if($total == 0) {
				return self::parseTemplate($template_block_empty, array());
			}

			$items_arr = array();
			foreach($words as $word) {
				$item_arr = array(
					'attribute:count'	=> $word['cnt'],
					'node:word'			=> $word['word']
				);

				$items_arr[] = self::parseTemplate($template_line, $item_arr);
			}

			$block_arr = array(
				'words'	=> array('nodes:word' => $items_arr),
				'total'	=> $total
			);

			return self::parseTemplate($template_block, $block_arr);
		}

		/**
		 * Отображение результатов поиска
		 * @param string $template шаблон
		 * @param string $searchString поисковая фраза
		 * @param int $perPage количество элементов на странице
		 * @param $p номер страницы
		 * @return mixed|string
		 */
		protected function sphinxSearch($template = 'default', $searchString = '', $perPage = 0, $p) {
			list(
				$template_block, $template_line, $template_empty_result, $template_line_quant
				) = self::loadTemplates("search/".$template,
				"search_block", "search_block_line", "search_empty_result", "search_block_line_quant"
			);

			if (!$searchString) {
				return $this->insert_form($template);
			}

			$result = Array();
			$items = Array();

			$index = '*';
			$limitResult = 1000;
			$config = mainConfiguration::getInstance();
			$sphinxHost = $config->get('sphinx', 'sphinx.host');
			$sphinxPort = (int) $config->get('sphinx', 'sphinx.port');


			$sphinx = new SphinxClient;
			$sphinx->SetServer($sphinxHost, $sphinxPort);
			if (!$sphinx->open()) {
				return;
			}

			$resultSphinx = $this->findResult($searchString, $limitResult, $index, $sphinx);
			if (empty($resultSphinx) || !array_key_exists('matches', $resultSphinx)) {
				return;
			}
			$resultMatches = $resultSphinx['matches'];
			$total = sizeof($resultMatches);
			$resultMatches = array_slice($resultMatches, $perPage * $p, $perPage);

			$i = $perPage * $p;
			foreach($resultMatches as $num => $element) {
				$item = Array();
				/** @var umiHierarchyElement $element */
				$page_weight = $element['weight'];
				$element = $element['page'];

				if(!$element) {
					continue;
				}

				$content = $element->getValue('content');
				$pattern = '/%[^\s](.*?)[^\s]%/i';
				$content = preg_replace($pattern, '', $content);

				$item['void:num'] = ++$i;
				$item['attribute:id'] = $element->getId();
				$item['attribute:name'] = $element->getName();
				$item['attribute:weight'] = $page_weight;
				$item['attribute:link'] = umiHierarchy::getInstance()->getPathById($element->getId());
				$item['xlink:href'] = "upage://" . $element->getId();
				$item['node:context'] = '<p>' . $this->highlighter(array($content), $searchString, $sphinx) . '</p>';
				$item['void:quant'] = ($num < count($resultMatches)-1? self::parseTemplate($template_line_quant, array()) : "");
				$items[] = self::parseTemplate($template_line, $item, $element->getId());

				templater::pushEditable(false, false, $element->getId());

				umiHierarchy::getInstance()->unloadElement($element->getId());
			}

			$result['subnodes:items'] = $result['void:lines'] = $items;
			$result['total'] = $total;
			$result['per_page'] = $perPage;
			$result['last_search_string'] = "";

			return self::parseTemplate(($total > 0 ? $template_block : $template_empty_result), $result);
		}

		/**
		 * Отправляет на Sphinx запрос для поиска данных
		 * @param $phrase поисковая фраза
		 * @param $limit
		 * @param $index
		 * @param $sphinx SphinxClient
		 * @internal param \SphinxClient $MAX_MATCHES Максимальное кол-во документов в результате, которое сфинкс держит в памяти
		 * @internal param $fieldWeights Веса полей в ранжировании результатов
		 * @return array
		 */
		protected function findResult($phrase, $limit, $index, $sphinx) {
			$config = mainConfiguration::getInstance();
			define('MAX_MATCHES' , 1000);
			define('HIGHLIGHT_INDEX' , 'content');

			$fieldWeights = array(
				'title' => (int) ($config->get('sphinx', 'sphinx.title') ? $config->get('sphinx', 'sphinx.title') : 10),
				'h1' => (int) ($config->get('sphinx', 'sphinx.h1') ? $config->get('sphinx', 'sphinx.h1') : 10),
				'meta_keywords' => (int) ($config->get('sphinx', 'sphinx.meta_keywords') ? $config->get('sphinx', 'sphinx.meta_keywords') : 5),
				'meta_descriptions' => (int) ($config->get('sphinx', 'sphinx.meta_descriptions') ? $config->get('sphinx', 'sphinx.meta_descriptions') : 3),
				'content' => (int) ($config->get('sphinx', 'sphinx.field_content') ? $config->get('sphinx', 'sphinx.field_content') : 1),
				'tags' => (int) ($config->get('sphinx', 'sphinx.tags') ? $config->get('sphinx', 'sphinx.tags') : 50)
			);

			if ($phrase) {
				$sphinx->open();

				$sphinx->SetSortMode(SPH_SORT_RELEVANCE);
				$sphinx->setFieldWeights($fieldWeights);

				$sphinx->setLimits(0, $limit, 1000);

				$event = new umiEventPoint("sphinxExecute");
				$event->setParam("sphinx", $sphinx);
				$event->setMode("before");
				$event->call();

				$sphinx->ResetGroupBy();
				$sphinx->SetFilter(
					'domain_id',
					array(
						cmsController::getInstance()->getCurrentDomain()->getId()
					)
				);

				$results = $sphinx->query($sphinx->escapeString($phrase), $index);

				$pages = umiHierarchy::getInstance();
				if (is_array($results) && array_key_exists('matches', $results)) {
					foreach ($results['matches'] as $id => $document) {
						if ($page = $pages->getElement($id)) {
							$results['matches'][$id]['page'] = $page;
						} else {
							unset($results['matches'][$id]);
						}
					}
				}

				return $results;
			}
		}

		/**
		 * Подсветка текста в сниппите
		 * @param $var массив текстов для подсветки
		 * @param $phrase поисковая фраза
		 * @param $sphinx SphinxClient
		 * @return mixed
		 */
		protected function highlighter($var, $phrase, $sphinx) {
			$res = $sphinx->buildExcerpts($var, HIGHLIGHT_INDEX, $phrase, array(
				'before_match' => '<strong>',
				'after_match' => '</strong>'
			));
			return $res[0];
		}
	};
?>