<?php
abstract class __custom_blogs20 {
	//TODO: Write here your own macroses
};
?>
