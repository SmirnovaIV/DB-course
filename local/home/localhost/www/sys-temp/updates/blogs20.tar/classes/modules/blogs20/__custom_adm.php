<?php
	abstract class __blogs20_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>