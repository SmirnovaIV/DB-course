<?php
	$permissions = Array(
		'banners_list' => Array(
			'add',
			'edit',
			'activity',
			'del',
			'lists',
			'places',
			'banner'
		),

		'insert' => Array(
			'go_to',
			'fastInsert',
			'fastinsert'
		)
	);
?>