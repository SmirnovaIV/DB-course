<?php
	abstract class __custom_banners {
		//TODO: Write here your own macroses
	};
?>