<?php
	abstract class __banners_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>