<?php
	abstract class __backup_custom {
		//TODO: Write here your own macroses
	};
?>
