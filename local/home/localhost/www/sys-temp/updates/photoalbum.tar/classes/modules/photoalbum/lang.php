<?php
$C_LANG = Array();

$C_LANG['module_name'] = "Фотогалереи";
$C_LANG['module_title'] = "Фотогалереи";
$C_LANG['module_description'] = "";

$C_LANG['config'] = "Настройки модуля";

$C_LANG['albums_list'] = "Список альбомов";
$C_LANG['album_add'] = $C_LANG['album_add_do'] = "Добавление альбома";
$C_LANG['album_edit'] = $C_LANG['album_edit_do'] = "Редактирование альбома";
$C_LANG['photos_list'] = "Список фотографий";
$C_LANG['photo_add'] = $C_LANG['photo_add_do'] = "Добавление фотографии";
$C_LANG['photo_edit'] = $C_LANG['photo_edit_do'] = "Редактирование свойств фотографии";

$C_LANG['albums'] = "Список альбомов";

$LANG_EXPORT = Array();

$LANG_EXPORT['nav_photoalbum_photo_edit'] = $C_LANG['photo_edit'];
$LANG_EXPORT['nav_photoalbum_photo_add'] = $C_LANG['photo_add'];

$LANG_EXPORT['photoalbum_cifi_upload_text'] = 'Закачать';
?>