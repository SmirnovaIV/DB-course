<?php
	$permissions = Array(
		'albums' => Array('album', 'subalbums', 'photo', 'view'), 
		'albums_list' => Array('albums_list', 'album_add', 'album_add_do', 'album_edit', 'album_edit_do', 'photos_list', 'photo_add', 'photo_add_do', 'photo_edit', 'photo_edit_do', 'album_blocking', 'photo_blocking', 'album_del', 'photo_del', 'album.edit', 'photo.edit', 'lists', 'add', 'edit', 'del', 'activity',
		'picasa', 'addPicasaPhoto', 'addNewPicasaPhotoalbum', 'generatePicasaButton', 'uploadImages', 'upload_arhive', 'publish', 'getPicasaLink')
	);
?>