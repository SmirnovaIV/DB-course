<?php
	abstract class __custom_photoalbum {
		//TODO: Write here your own macroses
	};
?>