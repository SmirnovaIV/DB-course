<?php
	$permissions = Array(
		'auto' => Array('getCurrencyCodeByAlias', 'export1C'),
		'exchange' => Array('import', 'export', 'add', 'edit', 'del', 'import_do', 'prepareElementsToExport'),
		'get_export' => Array()
	);
?>