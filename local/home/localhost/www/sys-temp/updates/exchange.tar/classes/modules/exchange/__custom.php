<?php
	abstract class __custom_exchange {
		//TODO: Write here your own macroses
	};
?>