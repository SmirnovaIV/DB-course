<?php
$C_LANG = Array();

$C_LANG['module_name'] = "SEO";
$C_LANG['module_title'] = "SEO";

$C_LANG['seo'] = "SEO";


$LANG_EXPORT = Array();
?>
