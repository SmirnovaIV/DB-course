<?php
	$permissions = array(
		'seo' => array('seo', 'links')
	);
?>