<?php
	abstract class __seo_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>