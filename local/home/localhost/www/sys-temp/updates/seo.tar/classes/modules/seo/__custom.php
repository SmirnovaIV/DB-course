<?php
	abstract class __custom_seo {
		//TODO: Write here your own macroses
	};
?>