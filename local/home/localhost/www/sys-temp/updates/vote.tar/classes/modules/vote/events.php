<?php
	$voteCloneElementEventListener = new umiEventListener("systemCloneElement", "vote", "onCloneElement");    
	
?>
