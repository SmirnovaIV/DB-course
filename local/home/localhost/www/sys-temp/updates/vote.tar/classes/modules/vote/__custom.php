<?php
	abstract class __custom_vote {
		//TODO: Write here your own macroses
	};
?>