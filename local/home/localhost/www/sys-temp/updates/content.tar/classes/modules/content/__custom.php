<?php
	abstract class __custom_content {
		//TODO: Write here your own macroses
	};
?>