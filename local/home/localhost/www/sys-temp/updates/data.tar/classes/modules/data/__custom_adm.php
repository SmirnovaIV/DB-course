<?php
	abstract class __data_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>