<?php
	abstract class __custom_users {
		//TODO: Write here your own macroses
	};
	
?>