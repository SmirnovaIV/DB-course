<?php
	abstract class __custom_adm_users {
		//TODO: Write here your own macroses (admin mode)
	};
?>
