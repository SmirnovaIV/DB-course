<?php
	abstract class __messages_users {
	}
?>
