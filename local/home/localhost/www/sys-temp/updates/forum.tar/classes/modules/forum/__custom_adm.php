<?php
	abstract class __forum_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>