<?php
	$permissions = Array(

		"view" => Array(
			'conf',
			'conf_last_message',
			'confs_list',
			'getmessagelink',
			'message',
			'message_post',
			'message_post_do',
			'topic',
			'topic_last_message',
			'topic_post',
			'topic_post_do',
		),

		"last_messages" => Array(
			'lists',
			'last_messages',
			'edit',
			'add',
			'del',
			'activity',
			'publish',
			'conf.edit',
			'message.edit',
			'topic.edit'
		)

	);
?>