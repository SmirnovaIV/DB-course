<?php
	abstract class __custom_forum {
		//TODO: Write here your own macroses
	};
?>