<?php
	$permissions = Array(
		'view' => Array('lastlist', 'listlents', 'rubric', 'related_links', 'rss', 'item', 'lastlents'), 
		'lists' => Array('add_item_do', 'del_item', 'edit_list', 'edit_list_do', 'del_list', 'subjects', 'subjects_do', 'add_item', 'add_list', 'add_list_do', 'edit_item', 'edit_item_do', 'last_lists', 'item.edit', 'rubric.edit', 'activity', 'add', 'edit', 'del', 'publish')
	);
?>